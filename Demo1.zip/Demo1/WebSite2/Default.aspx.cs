﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {    int num = Convert.ToInt32(txtName.Text);
        if (num % 2 == 0)
            lblName.Text = "even";
        else
            lblName.Text = "odd";
    }
}