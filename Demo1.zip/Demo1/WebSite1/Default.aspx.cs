﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    };lock;
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=DELL-PC\SQLEXPRESS;Initial Catalog=pubs;Integrated Security=True");
        string s = e.CommandArgument.ToString();
        string str = "select [title_id] from sales where title_id='" + s + "' ";
        con.Open();
        SqlCommand cmd = new SqlCommand(str, con);
        SqlDataAdapter ad = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        ad.Fill(ds);

        Label1.Text = ds.Tables[0].Rows[0][1].ToString();


    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}